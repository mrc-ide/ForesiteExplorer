
<!-- README.md is generated from README.Rmd. Please edit that file -->

# foresite

<!-- badges: start -->

![Site-Version](https://img.shields.io/badge/Site%20version-2022%2Fv1.0-green)
[![Project Status: WIP – Initial development is in progress, but there
has not yet been a stable, usable release suitable for the
public.](https://www.repostatus.org/badges/latest/wip.svg)](https://www.repostatus.org/#wip)
[![R-CMD-check](https://github.com/mrc-ide/foresite/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/mrc-ide/foresite/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

## Introduction

Foresite hosts the malaria site files, a set of inputs that can be used
as the basis for context-specific (e.g. country-level)
[malariasimulation](https://mrc-ide.github.io/malariasimulation/) runs.

[These pages](https://mrc-ide.github.io/foresite/) will walk through the
components of a site file, explaining the data that they use, how they
are derived and what assumptions underpin them.

There is also information on how sites are calibrated, how to run a site
in [malariasimulation](https://mrc-ide.github.io/malariasimulation/) and
what to do if you want to edit historical data or run future scenarios.

Please note that the site files have been parameterised using globally
available datasets and a number of inputs are only available at the
country level. As such, the spatial and temporal resolution of data can
be coarse. If you wish to use a site file as a starting point for a
context specific modelling run, it is strongly advised that you review
any context specific data available to you and use this to update and
recalibrate the site.

If using site files for research, you will need to go through each of
the site file sections and identify the underlying data and inputs
driving them. Relevant citations for all sources must be included - it
is not enough to cite this R package!

Key data sources we would like to acknowledge up front are:

The Word Malaria Report<sup>1</sup> and Malaria Atlas
Project<sup>2</sup>. Where malaria atlas project rasters have been used
as data sources, they have been accessed and downloaded using the
malariaAtlas R Package<sup>3</sup>. Other data sources are cited with
specific sections.

## Installation

With permissions, foresite can be installed with:
`remotes::install_github("mrc-ide/foresite")`

## Citations

<div id="refs" class="references csl-bib-body" line-spacing="2">

<div id="ref-WMR" class="csl-entry">

<span class="csl-left-margin">1. </span><span
class="csl-right-inline">World Health Organization. *World malaria
report*. (2021).</span>

</div>

<div id="ref-MAP" class="csl-entry">

<span class="csl-left-margin">2. </span><span
class="csl-right-inline">[Malaria atlas
project](https://malariaatlas.org/).</span>

</div>

<div id="ref-MAP_package" class="csl-entry">

<span class="csl-left-margin">3. </span><span
class="csl-right-inline">Pfeffer, D. *et al.* [malariaAtlas: An r
interface to global malariometric data hosted by the malaria atlas
project.](https://doi.org/10.1186/s12936-018-2500-5) *Malaria Journal*
**17**, 352 (2018).</span>

</div>

</div>
