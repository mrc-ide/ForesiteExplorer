test_that("laoding site works", {
  expect_type(get_site("COD"), "list")
})
