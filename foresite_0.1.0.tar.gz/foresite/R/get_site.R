#' Get site file for country
#'
#' @param iso3c Country ISO3c code.
#'
#' @return Site file
#' @export
#'
#' @examples get_site("BFA")
get_site <- function(iso3c){
  out <- do.call(what = `::`, args = list("foresite", iso3c))
  return(out)
}
