#' Sites
#' @format vector
"sites"


#' AFG Site File
#' @format list
"AFG"


#' AGO Site File
#' @format list
"AGO"


#' BDI Site File
#' @format list
"BDI"


#' BEN Site File
#' @format list
"BEN"


#' BFA Site File
#' @format list
"BFA"


#' BGD Site File
#' @format list
"BGD"


#' BOL Site File
#' @format list
"BOL"


#' BRA Site File
#' @format list
"BRA"


#' BWA Site File
#' @format list
"BWA"


#' CAF Site File
#' @format list
"CAF"


#' CIV Site File
#' @format list
"CIV"


#' CMR Site File
#' @format list
"CMR"


#' COD Site File
#' @format list
"COD"


#' COG Site File
#' @format list
"COG"


#' COL Site File
#' @format list
"COL"


#' COM Site File
#' @format list
"COM"


#' DJI Site File
#' @format list
"DJI"


#' DOM Site File
#' @format list
"DOM"


#' ECU Site File
#' @format list
"ECU"


#' ERI Site File
#' @format list
"ERI"


#' ETH Site File
#' @format list
"ETH"


#' GAB Site File
#' @format list
"GAB"


#' GHA Site File
#' @format list
"GHA"


#' GIN Site File
#' @format list
"GIN"


#' GMB Site File
#' @format list
"GMB"


#' GNB Site File
#' @format list
"GNB"


#' GNQ Site File
#' @format list
"GNQ"


#' GTM Site File
#' @format list
"GTM"


#' GUY Site File
#' @format list
"GUY"


#' HND Site File
#' @format list
"HND"


#' HTI Site File
#' @format list
"HTI"


#' IDN Site File
#' @format list
"IDN"


#' IND Site File
#' @format list
"IND"


#' KEN Site File
#' @format list
"KEN"


#' KHM Site File
#' @format list
"KHM"


#' LAO Site File
#' @format list
"LAO"


#' LBR Site File
#' @format list
"LBR"


#' MDG Site File
#' @format list
"MDG"


#' MLI Site File
#' @format list
"MLI"


#' MMR Site File
#' @format list
"MMR"


#' MOZ Site File
#' @format list
"MOZ"


#' MRT Site File
#' @format list
"MRT"


#' MWI Site File
#' @format list
"MWI"


#' NAM Site File
#' @format list
"NAM"


#' NER Site File
#' @format list
"NER"


#' NGA Site File
#' @format list
"NGA"


#' NIC Site File
#' @format list
"NIC"


#' PAK Site File
#' @format list
"PAK"


#' PAN Site File
#' @format list
"PAN"


#' PER Site File
#' @format list
"PER"


#' PHL Site File
#' @format list
"PHL"


#' PNG Site File
#' @format list
"PNG"


#' PRK Site File
#' @format list
"PRK"


#' RWA Site File
#' @format list
"RWA"


#' SDN Site File
#' @format list
"SDN"


#' SEN Site File
#' @format list
"SEN"


#' SLE Site File
#' @format list
"SLE"


#' SOM Site File
#' @format list
"SOM"


#' SSD Site File
#' @format list
"SSD"


#' SWZ Site File
#' @format list
"SWZ"


#' TCD Site File
#' @format list
"TCD"


#' TGO Site File
#' @format list
"TGO"


#' THA Site File
#' @format list
"THA"


#' TZA Site File
#' @format list
"TZA"


#' UGA Site File
#' @format list
"UGA"


#' VEN Site File
#' @format list
"VEN"


#' VNM Site File
#' @format list
"VNM"


#' YEM Site File
#' @format list
"YEM"


#' ZAF Site File
#' @format list
"ZAF"


#' ZMB Site File
#' @format list
"ZMB"


#' ZWE Site File
#' @format list
"ZWE"


